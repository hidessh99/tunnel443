#ifndef VNSTATD_H
#define VNSTATD_H

void showhelp(void);
void parseargs(DSTATE *s, int argc, char **argv);

#endif
