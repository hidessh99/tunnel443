#ifndef PARSEARGS_TESTS_H
#define PARSEARGS_TESTS_H

void add_parseargs_tests(Suite *s);

#endif
